# RangpurUI

A lightweight, standalone, production-ready UI framework designed for Bangladeshi developers and Islamic web applications. Build fast, accessible, and beautiful interfaces with a local first-class citizen approach.

## ✨ Features

- **Size-Conscious**: Under 50 KB gzipped, fully tree-shakable.
- **Standalone Architecture**: Zero external UI dependencies.
- **RTL-First**: Built-in support for Arabic/Urdu prayer apps using CSS logical properties.
- **12 Semantic Themes**: `islamic-green`, `ramadan`, `dhaka-night`, `rangpur`, `sylhet`, and more.
- **High Performance**: PostCSS-based Tailwind plugin for maximum optimization.

## 🚀 Installation

```bash
npm install rangpurui
```

## 🛠 Configuration

Add RangpurUI to your `tailwind.config.mjs` or `.ts`:

```javascript
// tailwind.config.ts
import rangpurui from "./noorui/dist/index.js";

export default {
  // ...
  plugins: [
    rangpurui,
  ],
}
```

## 🧩 Component Examples

### 1. Buttons

Standard button variants for all your actions.

**HTML**
```html
<button class="nui-btn nui-btn-primary">Primary Button</button>
<button class="nui-btn nui-btn-outline">Outline Button</button>
<button class="nui-btn nui-btn-ghost">Ghost Button</button>
<button class="nui-btn nui-btn-primary nui-btn-lg">Large Button</button>
```

**JSX (React/Next.js)**
```jsx
<button className="nui-btn nui-btn-primary">
  Primary Action
</button>

<button className="nui-btn nui-btn-outline">
  Secondary Action
</button>
```

---

### 2. Cards

Versatile containers for content.

**HTML**
```html
<div class="nui-card">
  <div class="nui-card-body">
    <h3 class="font-bold text-lg">Card Title</h3>
    <p>This is a standalone RangpurUI card component.</p>
    <div class="nui-card-actions mt-4">
      <button class="nui-btn nui-btn-primary nui-btn-sm">Confirm</button>
    </div>
  </div>
</div>
```

**JSX**
```jsx
<div className="nui-card bg-base-100 shadow-xl">
  <div className="nui-card-body">
    <h2 className="nui-card-title">New Component!</h2>
    <p>Standalone and dependency-free.</p>
    <div className="nui-card-actions justify-end">
      <button className="nui-btn nui-btn-primary">Buy Now</button>
    </div>
  </div>
</div>
```

---

### 3. Forms

Accessible and styled form controls.

**HTML**
```html
<label class="block text-sm font-bold mb-1">Full Name</label>
<input type="text" class="nui-input w-full" placeholder="Type here..." />

<label class="block text-sm font-bold mt-4 mb-1">Select City</label>
<select class="nui-select w-full">
  <option>Dhaka</option>
  <option>Rangpur</option>
</select>
```

**JSX**
```jsx
<div className="flex flex-col gap-4 max-w-sm">
  <input type="email" className="nui-input" placeholder="Email Address" />
  <div className="flex items-center gap-2">
    <span className="text-sm">Notifications</span>
    <input type="checkbox" className="nui-toggle" defaultChecked />
  </div>
</div>
```

---

### 4. Alerts

Important feedback for your users.

**HTML**
```html
<div class="nui-alert">
  <span>Your data has been saved!</span>
</div>

<div class="nui-alert nui-alert-success">
  <span>Success! Account created.</span>
</div>
```

---

### 5. Islamic Components (Specialized)

#### Prayer Time Card
**HTML**
```html
<div class="pt-card">
  <div class="pt-card-header hero-pattern-noor">
    <h3 class="pt-card-location">Dhaka</h3>
    <p class="pt-card-bismillah">بِسْمِ اللَّهِ</p>
  </div>
  <div class="pt-card-row pt-card-active">
    <span class="pt-card-name">Fajr</span>
    <span class="pt-card-time">5:15 AM</span>
  </div>
</div>
```

---

## 🎨 Themes

Apply themes using the `data-theme` attribute on any parent element:

```html
<html data-theme="islamic-green">
  <!-- Content here -->
</html>
```

Available Themes: `light`, `dark`, `cupcake`, `islamic-green`, `ramadan`, `hijri`, `dhaka-night`, `rangpur`, `sylhet`, `chittagong`, `coxsbazar`, `sundarban`.

## 🌍 RTL Support

RangpurUI uses logical properties. Simply add `dir="rtl"` to your HTML tag for full support.

```html
<html dir="rtl">
```

## ⚖️ License

MIT © [RangpurUI](https://github.com/supto707/noorui)
