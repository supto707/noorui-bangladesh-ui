/**
 * NoorUI — Card Component
 * Flexible container with hover effects, image support, and layout variants
 */

export default {
    '.nui-card': {
        'position': 'relative',
        'display': 'flex',
        'flex-direction': 'column',
        'border-radius': 'var(--rounded-box, 1.25rem)',
        'background-color': 'hsl(var(--b1))',
        'border': '1px solid hsl(var(--bc) / 0.08)',
        'overflow': 'hidden',
        'transition': 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
        '&:hover': {
            'box-shadow': '0 8px 30px rgba(0,0,0,0.06)',
        }
    },
    '.nui-card-body': {
        'display': 'flex',
        'flex-direction': 'column',
        'gap': '0.375rem',
        'padding': '1.25rem 1.5rem',
    },
    '.nui-card-title': {
        'font-size': '1.125rem',
        'font-weight': '700',
        'letter-spacing': '-0.02em',
        'margin-bottom': '0.125rem',
    },
    '.nui-card-actions': {
        'display': 'flex',
        'flex-wrap': 'wrap',
        'align-items': 'center',
        'justify-content': 'flex-end',
        'gap': '0.5rem',
        'margin-top': '0.75rem',
    },
    '.nui-card-bordered': { 'border-width': '1px' },
    '.nui-card-compact .nui-card-body': { 'padding': '1rem' },
    '.nui-card-side': { 'flex-direction': 'row' },
    '.nui-card-image-full': {
        'display': 'grid',
        '& > *': { 'grid-column-start': '1', 'grid-row-start': '1' },
        '& > figure img': { 'height': '100%', 'object-fit': 'cover' },
        '& .nui-card-body': { 'z-index': '1', 'background-color': 'hsl(var(--b1) / 0.75)', 'backdrop-filter': 'blur(12px)' }
    },
    'figure': {
        'display': 'flex',
        'align-items': 'center',
        'justify-content': 'center',
        '& img': { 'width': '100%', 'height': 'auto', 'object-fit': 'cover' }
    }
};
