/**
 * NoorUI — Forms & User Input
 * Polished inputs, selects, toggles, checkboxes, textareas, and range sliders
 */

export default {
    '.nui-form-control': {
        'display': 'flex',
        'flex-direction': 'column',
        'gap': '0.375rem',
        'width': '100%',
    },
    '.nui-label': {
        'display': 'flex',
        'user-select': 'none',
        'align-items': 'center',
        'justify-content': 'space-between',
        'padding': '0.25rem 0.125rem',
    },
    '.nui-label-text': {
        'font-size': '0.8125rem',
        'font-weight': '600',
        'color': 'hsl(var(--bc) / 0.8)',
        'letter-spacing': '-0.01em',
    },

    // ── Input ──
    '.nui-input': {
        'appearance': 'none',
        'height': '2.75rem',
        'width': '100%',
        'padding-inline': '0.875rem',
        'border-radius': 'var(--rounded-btn, 0.625rem)',
        'background-color': 'hsl(var(--b1))',
        'border': '1.5px solid hsl(var(--bc) / 0.12)',
        'font-size': '0.875rem',
        'color': 'hsl(var(--bc))',
        'transition': 'all 0.2s ease',
        '&::placeholder': { 'color': 'hsl(var(--bc) / 0.35)' },
        '&:focus': {
            'outline': 'none',
            'border-color': 'hsl(var(--p))',
            'box-shadow': '0 0 0 3px hsl(var(--p) / 0.08)',
        },
        '&:disabled': {
            'background-color': 'hsl(var(--b2))',
            'cursor': 'not-allowed',
            'opacity': '0.6',
        },
    },

    // ── Select ──
    '.nui-select': {
        'appearance': 'none',
        'height': '2.75rem',
        'width': '100%',
        'padding-inline': '0.875rem',
        'padding-right': '2.5rem',
        'border-radius': 'var(--rounded-btn, 0.625rem)',
        'background-color': 'hsl(var(--b1))',
        'border': '1.5px solid hsl(var(--bc) / 0.12)',
        'font-size': '0.875rem',
        'color': 'hsl(var(--bc))',
        'background-image': `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%239ca3af'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7' /%3E%3C/svg%3E")`,
        'background-repeat': 'no-repeat',
        'background-position': 'right 0.75rem center',
        'background-size': '1.125rem',
        'cursor': 'pointer',
        'transition': 'all 0.2s ease',
        '&:focus': {
            'outline': 'none',
            'border-color': 'hsl(var(--p))',
            'box-shadow': '0 0 0 3px hsl(var(--p) / 0.08)',
        },
    },

    // ── Checkbox & Radio ──
    '.nui-checkbox, .nui-radio': {
        'appearance': 'none',
        'width': '1.125rem',
        'height': '1.125rem',
        'border-radius': '0.3rem',
        'border': '1.5px solid hsl(var(--bc) / 0.25)',
        'cursor': 'pointer',
        'transition': 'all 0.15s ease',
        'display': 'grid',
        'place-content': 'center',
        'flex-shrink': '0',
        '&:checked': {
            'background-color': 'hsl(var(--p))',
            'border-color': 'hsl(var(--p))',
            'box-shadow': '0 1px 3px hsl(var(--p) / 0.3)',
        },
        '&::before': {
            'content': '""',
            'width': '0.55rem',
            'height': '0.55rem',
            'transform': 'scale(0)',
            'transition': '120ms transform ease-in-out',
            'box-shadow': 'inset 1em 1em white',
            'clip-path': 'polygon(14% 44%, 0 65%, 50% 100%, 100% 16%, 80% 0%, 43% 62%)',
        },
        '&:checked::before': { 'transform': 'scale(1)' },
        '&:focus-visible': { 'outline': '2px solid hsl(var(--p))', 'outline-offset': '2px' },
    },
    '.nui-radio': {
        'border-radius': '50%',
        '&::before': {
            'width': '0.45rem',
            'height': '0.45rem',
            'border-radius': '50%',
            'clip-path': 'none',
        }
    },

    // ── Toggle (Switch) ──
    '.nui-toggle': {
        'appearance': 'none',
        'width': '2.75rem',
        'height': '1.5rem',
        'border-radius': '1.5rem',
        'background-color': 'hsl(var(--bc) / 0.15)',
        'position': 'relative',
        'cursor': 'pointer',
        'transition': 'background-color 0.25s ease',
        'flex-shrink': '0',
        '&::after': {
            'content': '""',
            'position': 'absolute',
            'top': '2px',
            'left': '2px',
            'width': 'calc(1.5rem - 4px)',
            'height': 'calc(1.5rem - 4px)',
            'border-radius': '50%',
            'background-color': 'white',
            'transition': 'transform 0.25s cubic-bezier(0.4, 0, 0.2, 1)',
            'box-shadow': '0 1px 3px rgba(0,0,0,0.15)',
        },
        '&:checked': {
            'background-color': 'hsl(var(--p))',
            'box-shadow': '0 0 8px hsl(var(--p) / 0.3)',
        },
        '&:checked::after': { 'transform': 'translateX(1.25rem)' },
        '&:focus-visible': { 'outline': '2px solid hsl(var(--p))', 'outline-offset': '2px' },
    },

    // ── Textarea ──
    '.nui-textarea': {
        'appearance': 'none',
        'min-height': '5rem',
        'width': '100%',
        'padding': '0.75rem 0.875rem',
        'border-radius': 'var(--rounded-btn, 0.625rem)',
        'background-color': 'hsl(var(--b1))',
        'border': '1.5px solid hsl(var(--bc) / 0.12)',
        'font-size': '0.875rem',
        'color': 'hsl(var(--bc))',
        'resize': 'vertical',
        'line-height': '1.6',
        'transition': 'all 0.2s ease',
        '&::placeholder': { 'color': 'hsl(var(--bc) / 0.35)' },
        '&:focus': {
            'outline': 'none',
            'border-color': 'hsl(var(--p))',
            'box-shadow': '0 0 0 3px hsl(var(--p) / 0.08)',
        },
    },

    // ── Range ──
    '.nui-range': {
        'appearance': 'none',
        'width': '100%',
        'height': '1.5rem',
        'background': 'transparent',
        'cursor': 'pointer',
        '&::-webkit-slider-runnable-track': {
            'width': '100%',
            'height': '0.375rem',
            'background': 'hsl(var(--bc) / 0.1)',
            'border-radius': '0.5rem',
        },
        '&::-webkit-slider-thumb': {
            'appearance': 'none',
            'height': '1.25rem',
            'width': '1.25rem',
            'border-radius': '50%',
            'background': 'hsl(var(--p))',
            'border': '2px solid white',
            'margin-top': '-0.45rem',
            'box-shadow': '0 2px 6px hsl(var(--p) / 0.3)',
            'transition': 'box-shadow 0.2s ease',
        },
        '&:hover::-webkit-slider-thumb': {
            'box-shadow': '0 2px 12px hsl(var(--p) / 0.4)',
        }
    }
};
