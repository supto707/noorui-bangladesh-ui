/**
 * NoorUI — Data Display Components
 * Table, Badge, Avatar with premium polish
 */

export default {
    // ── Table ──
    '.nui-table': {
        'width': '100%',
        'text-align': 'left',
        'border-collapse': 'collapse',
        'font-size': '0.875rem',
        '& th': {
            'padding': '0.75rem 1rem',
            'font-weight': '600',
            'font-size': '0.75rem',
            'letter-spacing': '0.04em',
            'text-transform': 'uppercase',
            'color': 'hsl(var(--bc) / 0.5)',
            'border-bottom': '1px solid hsl(var(--bc) / 0.08)',
            'background-color': 'hsl(var(--b2) / 0.5)',
        },
        '& td': {
            'padding': '0.75rem 1rem',
            'border-bottom': '1px solid hsl(var(--bc) / 0.04)',
            'vertical-align': 'middle',
        },
        '& tr:hover': {
            'background-color': 'hsl(var(--b2) / 0.3)',
        },
        '& tr:last-child td': {
            'border-bottom': 'none',
        }
    },

    // ── Badge ──
    '.nui-badge': {
        'display': 'inline-flex',
        'align-items': 'center',
        'justify-content': 'center',
        'padding-inline': '0.625rem',
        'height': '1.375rem',
        'font-size': '0.6875rem',
        'font-weight': '600',
        'letter-spacing': '0.02em',
        'border-radius': '9999px',
        'background-color': 'hsl(var(--b3))',
        'color': 'hsl(var(--bc) / 0.7)',
        'white-space': 'nowrap',
    },
    '.nui-badge-primary': {
        'background-color': 'hsl(var(--p) / 0.12)',
        'color': 'hsl(var(--p))',
        'font-weight': '700',
    },
    '.nui-badge-secondary': {
        'background-color': 'hsl(var(--s) / 0.12)',
        'color': 'hsl(var(--s))',
    },
    '.nui-badge-outline': {
        'background': 'transparent',
        'border': '1px solid hsl(var(--bc) / 0.2)',
        'color': 'hsl(var(--bc) / 0.6)',
    },

    // ── Avatar ──
    '.nui-avatar': {
        'position': 'relative',
        'display': 'inline-flex',
        'height': '2.75rem',
        'width': '2.75rem',
        'flex-shrink': '0',
        '& img': {
            'width': '100%',
            'height': '100%',
            'object-fit': 'cover',
            'border-radius': 'var(--rounded-btn, 0.625rem)',
        },
        '&.nui-avatar-circle img': { 'border-radius': '50%' },
        '&.nui-avatar-ring': {
            'padding': '2px',
            'border': '2px solid hsl(var(--p))',
            'border-radius': '50%',
            '& img': { 'border-radius': '50%' },
        }
    }
};
