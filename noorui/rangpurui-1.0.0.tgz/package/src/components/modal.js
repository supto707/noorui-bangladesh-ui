/**
 * NoorUI — Modal Component
 * Premium dialog with spring animation and backdrop blur
 */

export default {
    '.nui-modal': {
        'position': 'fixed',
        'inset': '0',
        'z-index': '1000',
        'display': 'flex',
        'align-items': 'center',
        'justify-content': 'center',
        'padding': '1rem',
        'visibility': 'hidden',
        'opacity': '0',
        'transition': 'all 0.3s ease',
        'pointer-events': 'none',
        '&.nui-modal-open': {
            'visibility': 'visible',
            'opacity': '1',
            'pointer-events': 'auto',
            '& .nui-modal-box': { 'transform': 'scale(1) translateY(0)' }
        }
    },
    '.nui-modal-backdrop': {
        'position': 'absolute',
        'inset': '0',
        'background-color': 'hsl(0 0% 0% / 0.45)',
        'backdrop-filter': 'blur(8px)',
    },
    '.nui-modal-box': {
        'position': 'relative',
        'width': '100%',
        'max-width': '28rem',
        'background-color': 'hsl(var(--b1))',
        'padding': '1.75rem',
        'border-radius': '1.25rem',
        'border': '1px solid hsl(var(--bc) / 0.06)',
        'transform': 'scale(0.95) translateY(10px)',
        'transition': 'transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)',
        'box-shadow': '0 20px 60px -12px rgba(0,0,0,0.2)',
    },
    '.nui-modal-action': {
        'display': 'flex',
        'justify-content': 'flex-end',
        'gap': '0.5rem',
        'margin-top': '1.5rem',
    }
};
