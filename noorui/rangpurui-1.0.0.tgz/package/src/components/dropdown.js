/**
 * NoorUI — Dropdown Component
 * Smooth reveal with shadow and border
 */

export default {
    '.nui-dropdown': {
        'position': 'relative',
        'display': 'inline-block',
    },
    '.nui-dropdown-content': {
        'position': 'absolute',
        'top': '100%',
        'left': '0',
        'z-index': '50',
        'min-width': '12rem',
        'margin-top': '0.375rem',
        'background-color': 'hsl(var(--b1))',
        'border': '1px solid hsl(var(--bc) / 0.08)',
        'padding': '0.375rem',
        'border-radius': '0.75rem',
        'box-shadow': '0 10px 40px -8px rgba(0,0,0,0.12), 0 4px 12px rgba(0,0,0,0.06)',
        'opacity': '0',
        'visibility': 'hidden',
        'transform': 'translateY(-6px) scale(0.98)',
        'transition': 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
    },
    '.nui-dropdown:hover .nui-dropdown-content, .nui-dropdown-open .nui-dropdown-content': {
        'opacity': '1',
        'visibility': 'visible',
        'transform': 'translateY(0) scale(1)',
    },
    '.nui-dropdown-end .nui-dropdown-content': {
        'left': 'auto',
        'right': '0',
    }
};
