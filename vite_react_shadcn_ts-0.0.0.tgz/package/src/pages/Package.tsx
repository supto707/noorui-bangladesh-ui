import { Terminal, Github, Package as PackageIcon, Shield, Zap, Palette, Globe, ChevronLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";

const Package = () => {
    return (
        <div className="min-h-screen bg-background text-foreground scroll-smooth">
            {/* Navbar */}
            <nav className="sticky top-0 z-50 backdrop-blur-md bg-background/80 border-b border-border">
                <div className="container max-w-6xl mx-auto flex items-center justify-between py-3 px-4">
                    <Link to="/" className="flex items-center gap-2 cursor-pointer">
                        <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                            <span className="text-primary-content font-bold text-sm">R</span>
                        </div>
                        <span className="font-display font-bold text-lg">RangpurUI</span>
                    </Link>
                    <div className="flex items-center gap-4">
                        <Link to="/" className="text-sm font-semibold hover:text-primary flex items-center gap-1 transition-colors">
                            <ChevronLeft className="w-4 h-4" /> Back to Home
                        </Link>
                        <a href="https://github.com" target="_blank" rel="noreferrer" className="nui-btn nui-btn-outline nui-btn-primary nui-btn-sm font-bold rounded-xl border-2 hover:scale-105 transition-transform flex items-center">
                            <Github className="w-4 h-4 mr-2" /> GitHub
                        </a>
                    </div>
                </div>
            </nav>

            {/* Header */}
            <section className="py-20 bg-primary text-primary-content relative overflow-hidden">
                <div className="rui-pattern absolute inset-0 opacity-20" />
                <div className="container max-w-6xl mx-auto px-4 relative z-10">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6 }}
                    >
                        <h1 className="text-4xl md:text-6xl font-black mb-4">Installation & Usage</h1>
                        <p className="text-primary-content/80 text-lg max-w-2xl font-medium"> Everything you need to get started with RangpurUI in your project.</p>
                    </motion.div>
                </div>
            </section>

            <main className="container max-w-5xl mx-auto px-4 py-20 pb-40">
                <div className="mb-12">
                    <h1 className="text-4xl font-extrabold mb-2 tracking-tight">npm Package Structure</h1>
                    <p className="text-muted-foreground text-lg">Tree-shakable, framework-agnostic distribution</p>
                </div>

                <div className="grid lg:grid-cols-2 gap-8 mb-8">
                    {/* Installation Card */}
                    <div className="bg-muted/30 border border-border/50 rounded-3xl p-8 shadow-sm">
                        <h2 className="font-extrabold text-xl mb-6">Installation</h2>

                        <div className="bg-[#EAECEB] dark:bg-[#1A1D1C] text-sm text-[#4E5B53] dark:text-[#A0AFAA] font-mono p-4 rounded-xl mb-6 flex justify-between items-center group">
                            <code>$ npm install rangpurui</code>
                        </div>

                        <div className="bg-[#EAECEB] dark:bg-[#1A1D1C] p-6 rounded-2xl relative">
                            <pre className="text-sm font-mono leading-loose text-[#4E5B53] dark:text-[#A0AFAA]">
                                <code>
                                    <span className="opacity-50">// tailwind.config.js</span><br />
                                    <span className="font-bold text-foreground">module.exports</span> = {'{'}<br />
                                    {'  '}plugins: [<br />
                                    {'    '}<span className="text-primary">require</span>(<span className="text-secondary">'rangpurui'</span>)({'{'}<br />
                                    {'      '}themes: [<span className="text-secondary">'islamic-green'</span>, <span className="text-secondary">'ramadan'</span>],<br />
                                    {'      '}prefix: <span className="text-secondary">'rui-'</span>,<br />
                                    {'    '}{'}),'}<br />
                                    {'  '}],<br />
                                    {'}'}
                                </code>
                            </pre>
                        </div>
                    </div>

                    {/* Bundle Size Card */}
                    <div className="bg-muted/30 border border-border/50 rounded-3xl p-8 shadow-sm flex flex-col justify-between">
                        <div>
                            <h2 className="font-extrabold text-xl mb-8">Bundle Size</h2>

                            <div className="space-y-6">
                                <div>
                                    <div className="flex justify-between text-sm font-bold mb-2">
                                        <span>Full library</span>
                                        <span className="text-primary tracking-tight">~42KB</span>
                                    </div>
                                    <div className="h-3 bg-border/40 rounded-full overflow-hidden">
                                        <div className="h-full bg-primary rounded-full w-[85%]" />
                                    </div>
                                </div>

                                <div>
                                    <div className="flex justify-between text-sm font-bold mb-2">
                                        <span>CSS only</span>
                                        <span className="text-primary tracking-tight">~35KB</span>
                                    </div>
                                    <div className="h-3 bg-border/40 rounded-full overflow-hidden">
                                        <div className="h-full bg-primary rounded-full w-[70%]" />
                                    </div>
                                </div>

                                <div>
                                    <div className="flex justify-between text-sm font-bold mb-2">
                                        <span>1 theme + 5 components</span>
                                        <span className="text-primary tracking-tight">~8KB</span>
                                    </div>
                                    <div className="h-3 bg-border/40 rounded-full overflow-hidden">
                                        <div className="h-full bg-primary rounded-full w-[15%]" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <p className="text-xs font-bold text-muted-foreground opacity-60 mt-8 leading-relaxed">
                            All sizes gzipped. Fully tree-shakable — import only what you need.
                        </p>
                    </div>
                </div>

                {/* Framework Supported Row */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {['React', 'Vue', 'Next.js', 'Vanilla JS'].map((framework) => (
                        <div key={framework} className="bg-background border border-border/60 hover:border-primary/30 transition-colors rounded-2xl p-6 flex flex-col items-center justify-center text-center shadow-sm hover:shadow-md">
                            <h3 className="font-extrabold text-[15px] text-primary">{framework}</h3>
                            <span className="text-xs text-muted-foreground font-semibold mt-1 opacity-70">Supported</span>
                        </div>
                    ))}
                </div>
            </main>

            <footer className="py-16 bg-card border-t border-border mt-20">
                <div className="container max-w-6xl mx-auto px-4 text-center">
                    <p className="text-sm font-bold opacity-40 uppercase tracking-widest">© 2026 RangpurUI Framework. All rights reserved.</p>
                </div>
            </footer>
        </div>
    );
};

export default Package;
